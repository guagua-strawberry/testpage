# frozen_string_literal: true

module JekyllIncludeCache
  VERSION = "0.2.1"
end
